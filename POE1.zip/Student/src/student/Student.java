/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package student;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
class Student { 
    private final String id;
    private final String name;
    private final int age;
    private final String email;
    private final String course;
    
    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
        
    }
    
    public String getID() {
        return id;
    }
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }
    public String getEmail() {
        return email;
    }
    public String getCourse(){
        return course;
    
    }
    @Override
    public String toString(){
        return "Student ID: " + id + "\nName: " + name + "\nAge: " + age + "\nEmail: " + email + "\nCourse: " + course;
    }
    }
class StudentManagementSystem {
    static 
            ArrayList<Student> studentList = new ArrayList<>();
    private static final Scanner scanner = new Scanner(System.in);
    
    public static void saveStudent() {
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine();
        
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        
        int age = getValidStudentAge();
        
        System.out.print("Enter Student Email: ");
        String email = scanner.nextLine();
      
        System.out.print("Enter Student Course: ");
        String course = scanner.nextLine();
        
        Student student = new Student(id, name, age, email, course);
        studentList.add(student);
        System.out.println("Student details have been successfully saved");
    }
    private static int getValidStudentAge() {
        int age = 0;
        boolean validAge = false;
        while (!validAge) {
            System.out.print("Enter Student age (Student must be 16 or older)");
            String ageInput = scanner.nextLine();
        try {
            age = Integer.parseInt(ageInput);
            if (age >=16) {
                validAge = true;
            }
            else {
                System.out.print("Invalid age. Age must be 16 or older.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid number for age.");
        }
        }
        return age;
    }
    public static void searchStudent() {
        System.out.print("Enter Student ID to search");
        String id = scanner.nextLine();
        
        Student student = findStudentById(id);
        
        if (student != null) {
            System.out.print("Student found: \n" + student);
        }
        else { System.out.println("Student not found. ");
            }
    }
    public static void deleteStudent() {
        System.out.print("Enter Student ID to delete: ");
        String id = scanner.nextLine();
        
        Student student = findStudentById(id);
        
        
        System.out.print("Are you sure you want to delete this student? (yes/no)");
        String confirmation = scanner.nextLine();
        
        if (confirmation.equalsIgnoreCase("yes")) {
            studentList.remove(student);
            System.out.println("Student deleted successfully.");
        }
        else {
            System.out.println("Deletation canceled.");
        }
         
    }
        static Student findStudentById(String id) {
            for (Student student: studentList) {
                if (student.getID().equals(id)) {
                    return student;
                }
            }
            return null;
        }
        
        public static void studentReport() {
            if (studentList.isEmpty()) {
                System.out.println("No students avaliable.");
            } else {
                System.out.println("Student Report:");
            for (Student student: studentList){
                System.out.println(student);
                System.out.println("-------------------");
            }
            }
        }
        
        public static void exitApplication() {
            System.out.println("Exiting the application.");
            System.exit(0);
        }
        
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Student Manageent System Menu");
        System.out.println("1. Save a New student");
        System.out.println("2. Search for a New Student");
        System.out.println("3. Delete a student");
        System.out.println("4. View Student Report");
        System.out.println("5. Exit");
        
        System.out.print("Choose an option: ");
        
        String choice = scanner.nextLine();
        
        switch (choice) {
            case "1": 
                saveStudent();
            break;
            
            case "2": 
                searchStudent();
            break;
            
            case "3": 
                deleteStudent();
            break;
            
            case "4": 
                studentReport();
            break;
            
            case "5":
                exitApplication();
            break;
            
            default: 
                System.out.println("Invalid choice. Please select a valid option.");
        }
    }
}

