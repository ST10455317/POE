/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package student;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class StudentManagementSystemTest {

    public void setUp() {
        StudentManagementSystem.studentList.clear();
    }
    

    /**
     * Test of saveStudent method, of class StudentManagementSystem.
     */
    @Test
    public void testSaveStudent() {
        Student student = new Student("101", "Alice", 18, "alice@exaple.com", "DISD");
        StudentManagementSystem.studentList.add(student);
        assertEquals(1,StudentManagementSystem.studentList.size());
        assertEquals("Alice", StudentManagementSystem.studentList.get(0).getName());
    }
    
    @Test
    public void testSearchStudent_Found() {
        Student student = new Student("101", "Alice", 18, "alice@exaple.com","DISD");
        StudentManagementSystem.studentList.add(student);
        
        Student foundStudent = StudentManagementSystem.findStudentById("101");
        assertNotNull(foundStudent);
        assertEquals("Alice", foundStudent.getName());
    }
    @Test
    public void testSearchStudent_NotFound() {
        Student foundStudent = StudentManagementSystem.findStudentById("999");
        assertNull(foundStudent);
    }
    
    @Test
    public void testDeleteStudent_found() {
        Student student = new Student("101", "Alice", 18, "alice@exaple.com","DISD");
        StudentManagementSystem.studentList.add(student);
        
        StudentManagementSystem.studentList.remove(student);
        assertEquals(0, StudentManagementSystem.studentList.size());
    }
    @Test
    public void testDeleteStudent_Notfound() {
        int initialSize = StudentManagementSystem.studentList.size();
        StudentManagementSystem.deleteStudent();
        assertEquals(initialSize, StudentManagementSystem.studentList.size());
      
    }

    /**
     * Test of studentReport method, of class StudentManagementSystem.
     */
    @Test
    public void testStudentReport() {
        System.out.println("studentReport");
        StudentManagementSystem.studentReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of exitApplication method, of class StudentManagementSystem.
     */
    @Test
    public void testExitApplication() {
        System.out.println("exitApplication");
        StudentManagementSystem.exitApplication();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class StudentManagementSystem.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        StudentManagementSystem.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
